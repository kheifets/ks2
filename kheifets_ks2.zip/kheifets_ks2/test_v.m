function test = test_v(u)
% Computes CvM and KS norms of empirical processes  V_{1n} and V_{2n} for series u;
% INPUT: series u, T x 1;
% OUTPUT: array of structures test,
% where test(k).sinfo is an array (row-vector) of strings with statistics,
% i.e. CvM_{0}, KS_{0},CvM_{1},KS_{2},...
% and test(k).stat is a raw vector of doubles of corresponding test
% statistics;
% Lag 0 (unconditional Kolmogorov test) is computed always, other
% lags must be specified in vlags;
% uses function normv2l(u,vlags);
% Copyright (C) 2012 Igor Kheifets, GNU GPL v3.
    
% vlags = [1 2 3 4 5];
   vlags = [1 2]; %
nvlags = length(vlags);

if nargin == 0 % determine return size and info only
    nstat = 2*(nvlags+1);
    stat = zeros(1,nstat);
    statp = zeros(1,nstat);
    info = '';
    return
else
     % give info
    infocvm=cell(1,nvlags);
    infoks=cell(1,nvlags);
    for ilag=1:nvlags,
        s=['{' num2str(vlags(ilag)) '}'];
        infocvm(ilag)={['CvM_' s] };
        infoks(ilag)={['KS_' s] };


    end

    infocvm0={'CvM_0'};
    infoks0={'KS_0'};
  
    infov2=[infocvm0 infocvm infoks0 infoks];

    [stats]=normv2l(u,vlags);
    stats=stats';
    ind=1:2:(2*nvlags+1);
    statv2(1:nvlags+1)=stats(ind);
    statv2(nvlags+2:2*nvlags+2)=stats(ind+1);

    test(:).stat = statv2;
    test(:).sinfo = infov2;
end
