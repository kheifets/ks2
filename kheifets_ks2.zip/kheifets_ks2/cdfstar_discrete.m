function ustar = cdfstar_discrete(y,x, p,v)
% random PIT for discrete distribution (say ordered probit, OP)
% y: T x 1, dependent discrete rv on 1,2,...,k
% x: T x p, regressors
% p: T x k, probability estimates from mnrval
% v: T x 1, additional random-smoother
% Copyright (C) 2012 Igor Kheifets and Carlos Velasco, GNU GPL v3.
    
      
[T,k1]=size(x);
   
    p=[zeros(T,1) p];
    y = y +1;
    index= sub2ind(size(p), (1:T)', y);
    index1=sub2ind(size(p), (1:T)', y+1);
    
%     if size(v,1)~=T
%         v=rand(T,1);
%     end
    
    f=cumsum(p,2);
    
    ustar=f(index)+p(index1).*v;
    
end
