This a readme file describes how use the code for specification testing using the test from Kheifets (2015) and Kheifets and Velasco (2013).

The fastest way to get
test statistics is to use "test_v", because it uses
precompiled in C funciton with  exact formulas,
avoiding numerical/grid approximations. To run  "test_v" you need first
to compile in your system "normv2l.c" with mex.

The test can be applied both to continuous and discrete conditional cdf. You need
to obtain PITs, U_t. For example, to test GARCH models, apply unconditional cdf of innovations (say normal or Student t_v) to the residuals from "garchfit"; to test discrete models, apply "cdfstar_discrete" to the residuals from "mnrfit".

Matlab functions:

test_v
% Computes CvM and KS norms of empirical processes V_{1n} and V_{2n} for series u at different lags (uses compiled normv2l.c with exact formula, no numerical integration/no grids);

cdfstar_discrete
% random PIT for discrete distribution, see Kheifets and Velasco (2012)

V2n 
% Computes the value of empirical process V_{2n}

Function in C:

normv2l.c 
% Computes CvM and KS norms of empirical processes V_{1n} and V_{2n} for series u; written in C, to be compiled in Matlab with "mex"; exact formula, no numerical integration/no grids)
