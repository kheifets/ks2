function ret=V2n(u,r)
% Computes the value of empirical process V_{2n} for
% series u(:,1) and u(:,2) at point r, see Kheifets(2012);
% INPUTS: 
% series u, T x 2; series with lags to be computed
% r: 1 x 2, point in [0,1]^2 unit square
% OUTPUTS:  1 x 1, the value of empirical process V_{2n}
% USAGE: run in Matlab ret=normV2ngrid([u(2:(end)), u(1:(end-1))],[0.5, 0.5]);
% Copyright (C) 2012 Igor Kheifets, GNU-GPL-v3. 
%n=size(u,1);
%ret=mean((u(:,1)<=r(1)).*(u(:,2)<=r(2)),1)-r(1)*r(2);
ret=mean((u(:,1)<=r(1))&&(u(:,2)<=r(2)),1)-r(1)*r(2);
end