#include<math.h>

#include "mex.h"

/*
*  -
* This is a helper function.
* You can compile it and should work on any platform.

% Computes CvM and KS norms of of empirical processes V_{1n} and V_{2n} for series u;
% INPUT: series u, T x 1; series with lags to be computed
% OUTPUT: array of test statistics,
% i.e. CvM_{0}, KS_{0},CvM_{1},KS_{1},...
% Lag 0 (unconditional Kolmogorov test) is computed always, other
% lags mst be specified in vlags;
% Copyright (C) 2012 Igor Kheifets, GNU GPL v3.
*/

/*
double max(double a, double b) {
	double c;
	if (a>b) c=a;
	else c=b;
	return c;

} */

//#ifdef __cplusplus

  double maxd (double value1, double value2);

  double maxd(double value1, double value2)
  {
     return ( (value1 > value2) ? value1 : value2);
  }

//#endif

void transpos (double *a, int i, int j) {     //????????????
	double c;
	c=a[i];
	a[i]=a[j];
	a[j]=c;
}

void sort (double *a, int n) {
	int i,k;
	for (k=1; k<=n; k++)	{
	  for (i=k;i>1&&a[i-1]<a[i-2];i--)
	  //transpos (a[i-1], a[i-2]);             //??????? a[k]
	    transpos (a,i-2,i-1);
	}
}

void copyarr(double *u, double *y,int n) {
	int i;
	for(i=0;i!=n;i++) {
		y[i]=u[i];
	}
}

double* zeros( int n) {
	int i;
    double *x;
    x = mxCalloc(n, sizeof(double));
	for(i=0;i!=n;i++) {
		x[i]=0;
	}
    return x;
}


void copyarriflarger(double *u, double *y,int n) {
	int i;
	for(i=0;i!=n;i++) {
        y[i] = maxd(y[i],u[i]);
//		if (y[i]>u[i]) {
//    }
	}
}

int put01 (double *a, int n) {
	int i,k, nn;
	nn=n-3;// real number of elements -1, points to the last element
	for (k=0; k<(nn); k++)	{
		if (a[k]==a[k+1]) {  // delete repetitions
			for (i=k+1; i<(nn); i++)	{
				a[i]=a[i+1];
			}
			nn--;
            k--; // ?? added 2011/9/13
		}
	}
	if (a[nn]!=1) { // if last is not 1 add 1 to the right
		a[++nn]=1;
	}
	if (a[0]!=0) {  // if first is not 0 add 0 to the left
		for (k=++nn; k!=0; k--)	{  // add space to the left
			a[k]=a[k-1];
		}
		a[0]=0;
	}
	return ++nn;
}


double indicator_sum (double *u1, double *u2, int n, double r1, double r2) {
	int i;
	double ret=0;
	for(i=0; i!=n; i++) {
		ret+=((*(u1+i)<=r1) & (*(u2+i)<=r2));
	}
	return ret/n; // add /n
}

// void sqpart (double *u1, double *u2, int n, int m,
// 				 double *a, double *b, double *c, double *d) {
// 	// u1 and u2 are sorted without repeatitions with data 0...n-1 and 0...m-1
// 	// n-1 * m-1 squares
// 	int i,j;
// 	for(i=0; i!=n-1; i++) {
// 		for(j=0; i!=m-1; j++) {
// 			*(a+i*(m-1)+j)=*(u1+i);
// 			*(b+i*(m-1)+j)=*(u2+j);
// 			*(c+i*(m-1)+j)=*(u1+i+1);
// 			*(d+i*(m-1)+j)=*(u2+j+1);
// 		}
// 	}
// 	return;
// }

void normV1 (double *u, int n,  double * stats, mwSize *pos) {
// u must be sorted
	double cvm=0,ks=0;
	int i;
	
    cvm=pow(*(u), 3)/3;
    for(i=1;i<n;i++) {  
// k=1,...n-1, int{((k)/n)^2-2((k)/n)*r+r^2}=
        //=((k)/n)^2*r - ((k)/n)*r^2 + r^3/3 | ^{u[k]} _{u_[k-1]}
        // left corner  r^3/3 | u[0]
        // right corner  r - r^2 + r^3/3 | ^{1} _{u_[n-1]}
        
       
        cvm += pow((double)i/n, 2) * (*(u+i) - *(u+i-1)) -
                ((double)i/n) * (pow(*(u+i), 2)-pow(*(u+i-1), 2)) +
                ((double)1/3) * (pow(*(u+i), 3)-pow(*(u+i-1), 3));
    }
 // last interval
	cvm+= (double)1/3 - *(u+n-1) + pow(*(u+n-1),2) - pow(*(u+n-1),3)/3;
	
    for(i=0;i<n;i++) {
        ks = maxd(fabs((double)(i+1)/n-*(u+i)), ks);
        ks = maxd(fabs((double)(i)/n-*(u+i)), ks);
    }
    
	*(stats+*pos) = cvm*n; (*pos)++;
    *(stats+*pos) = ks*sqrt(n); (*pos)++;
   //	return cvm;
}

void normV2(mwSize T, double *u, mwSize Txx, double *xx, double dlag,  double * stats, mwSize *pos) {

	int nn,mm,i,j;
	double h,tmp;
    double ks=0,cvm=0;

	double y1sq,y2sq, y1sqnext, y2sqnext ;
	double dy1,dy1sq,dy1cu;
	double dy2,dy2sq,dy2cu;
    int n;
    
    int lag=dlag;
	double *u1,*u2;
    u1 = u+lag;
    u2 = u;
    n=T-lag;
    
	double *y1,*y2;
    y1 = xx;
    y2 = xx;
   
	nn=Txx;
	mm=Txx;

	for(i=0;i!=(nn-1);i++)  {

		y1sq = y1[i]*y1[i];
		y1sqnext = y1[i+1]*y1[i+1];
		dy1 = y1[i+1]-y1[i];
		dy1sq = y1sqnext-y1sq;
		dy1cu = y1sqnext*y1[i+1]-y1sq*y1[i];


		for(j=0;j!=(mm-1);j++)  {
			h=indicator_sum (u1,u2, n, y1[i], y2[j]);
			tmp=maxd(fabs(h-y1[i]*y2[j]), fabs(h-y1[i+1]*y2[j+1]));
			ks=maxd(tmp,ks);
			//cout<<h<<",";

			y2sq=y2[j]*y2[j];
			y2sqnext=y2[j+1]*y2[j+1];
			dy2=y2[j+1]-y2[j];
			dy2sq=y2sqnext-y2sq;
			dy2cu=y2sqnext*y2[j+1]-y2sq*y2[j];


			//cout<<h*h<<","<< (h/2)<<";";
			//cout<<dy1*dy2<<","<<dy1sq*dy2sq/4<<","<<dy1cu*dy2cu/9<<";";
			//cout<< h*h*dy1*dy2- (h/2)*dy1sq*dy2sq+ (1/9)*dy1cu*dy2cu<<",";

			cvm+= h*h*dy1*dy2- h*dy1sq*dy2sq/2+ dy1cu*dy2cu/9;
		}

	}

	*(stats+*pos)  =cvm*n; (*pos)++;
	*(stats+*pos) =ks*sqrt(n); (*pos)++;
	
}



/*
void main (void) {
	int i,n,m,k;
	int const nn=4;
	//double *stat;
	//double stat[2]={0,0};
	//double a[nn];
	//double a[nn]={0.1,0.1,0.2,0.6,0.8};

	double u1[nn]={0.6,0.2,0.1,0.8};
	double u2[nn]={0.2,0.2,0.15,0.9};
	double stat[2]={0,0};
	n=nn; m=nn;
	makeh (u1,u2, n, m, stat );
	cout<<stat[0]<<" "<<stat[1];

} */



void normV2L(mwSize T, double *u, double *xx, mwSize nlags, double *lags,  double *stats, mwSize *pos)
{
  
    mwSize ilag;
    mwSize Txx;
    
    
	copyarr(u,xx,T);
	sort(xx,T);
    normV1 (xx,T,stats,pos);

	// delete repetitions and put 0 and 1 to the corners
	Txx=put01(xx,T+2);
    
    
    //double *statsnow;
    //statsnow = stats;
    for (ilag=0; ilag<nlags; ilag++) {
       // stats = stats + ilag * 2;
        normV2(T,u,Txx,xx,lags[ilag],stats,pos);
        //*stats=lags[nlags-1];
    }  
    
   
}

void normV2Lseq(mwSize T, double *u, double *xx, mwSize nlags, double *lags,  double *stats, mwSize *pos)
{
  
    mwSize ilag;
    mwSize Txx;
    mwSize TT;
    
    TT=T;
    
    double *statsnew;
    mwSize *posnew = 0;
    mwSize nstats = 2*(1+nlags);
    
    //statsnew = mxCalloc(nstats, sizeof(double));
    statsnew = zeros(nstats);
    posnew = mxCalloc(1, sizeof(mwSize));

    for (T=3; T<TT; T++) {
        
        *posnew = 0;
        
        copyarr(u, xx, T);
        sort(xx, T);
        normV1(xx, T, statsnew, posnew);
        
        // delete repetitions and put 0 and 1 to the corners
        Txx=put01(xx, T+2);
        
        
        //double *statsnow;
        //statsnow = stats;
        for (ilag=0; ilag<nlags; ilag++) {
            // stats = stats + ilag * 2;
            normV2(T, u, Txx, xx, lags[ilag], statsnew, posnew);
            //*stats=lags[nlags-1];
        }
        copyarriflarger(stats,statsnew,nstats);
        
    }
    *pos = *posnew;
     mxFree(statsnew);
      mxFree(posnew);
    
}

void normV2M(mwSize T, mwSize M, double *u,double *xx, mwSize nlags, double *lags, double *stats, mwSize *pos) 
{
  double *unow;

  unow = u;
 // mwSize *pos=0;
  
    mwSize iM;
    for (iM=0; iM<M; iM++) {
        unow = unow + iM*T;
        //normV2L(T, unow, nlags, lags, ngrid, stats,pos);
        normV2L(T, u,xx, nlags, lags,  stats,pos);
    }
  
}



/* The gateway function */
void mexFunction( int nlhs, mxArray *plhs[],
        int nrhs, const mxArray *prhs[]) {
    
    double *u;               /* 1xN input matrix */
     double *xx; 
    mwSize T,M;                   /* size of matrix */
    mwSize nlags;                   /* size of matrix */
    mwSize nstats=0;                   /* size of matrix */
    double *lags;                   /* size of matrix */
   // mwSize lagsr;                   /* size of matrix */
   // mwSize ngrid;
    //mxLogical *c;              /* output matrix */
    mwSize dims[1];
    double *stats;
     double  *stats2;
     mwSize *pos=0;
    

    /* check for proper number of arguments */
    if(nrhs!=2) {
        mexErrMsgIdAndTxt("MyToolbox:normc2lg:nrhs","Two inputs required.");
    }
//     if(nlhs!=1) {
//         mexErrMsgIdAndTxt("MyToolbox:arrayProduct:nlhs","One output required.");
//     }

   


   

    /* get dimensions of the input matrix */
    T = mxGetM(prhs[0]);
    M = mxGetN(prhs[0]);
    
    /* get dimensions of the input matrix */
   // lagsr = mxGetM(prhs[1]);
    nlags = mxGetN(prhs[1]);
    
    
      /* The input must be a noncomplex scalar double.*/

//   if(  mxIsComplex(prhs[2]) ||
//       !(mxGetM(prhs[2])==1 && mxGetN(prhs[2])==1) ) {
//     mexErrMsgTxt("Input must be a noncomplex scalar.");
//   }
    
      /* check that number of rows in second input argument is 1 */
    if(mxGetM(prhs[1])!=1) {
        mexErrMsgIdAndTxt("MyToolbox:normc2lg:notRowVector","2d Input - lags - must be a row vector.");
    }
    /* create a pointer to the real data in the input matrix  */
    u = mxGetPr(prhs[0]);
    lags = (double*)mxGetData(prhs[1]);
   // ngrid = (mwSize)mxGetScalar(prhs[2]);
 

    /* create the output matrix */
    dims[0] = 2*(1+nlags)*M; // number of statistics
    //dims[1] = M; // M
    plhs[0] = mxCreateNumericArray(1, dims, mxDOUBLE_CLASS, mxREAL);
    stats =  (double*)mxGetData(plhs[0]);
    
    pos = mxCalloc(1, sizeof(mwSize));
    
    
//     dims[0] = 1;
//       plhs[1] = mxCreateNumericArray(1, dims, mxDOUBLE_CLASS, mxREAL);
//     stats2 =  (double*)mxGetData(plhs[1]);//
//     *stats2=lags[1];
 //       c =  mxGetData(plhs[0]);

//     plhs[0] = mxCreateLogicalMatrix(ar,bc);
//     c = mxGetLogicals(plhs[0]);


    /* call the computational routine */
     xx = mxCalloc(T+2, sizeof(double));
    normV2M(T,M,u,xx,nlags,lags,stats,pos); 
    mxFree(pos);
    mxFree(xx);
    
//     *(stats2++)=M;
//     *(stats2++)=ngrid;
//     *(stats2++)=*(stats--);
// //     *(stats2++)=*(stats);
//     *(stats2++)=1;
//     *(stats2++)=2;
//     *(stats2++)=3;
//     *(stats2++)=5;
   // *(stats2++)=*(stats--);
    //mxFree(variable);
}

//	makeh(u1,u2, n1,n2, cvm,ks);
	//cvmv1(data,n,stat);

